﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using System.Data.SqlClient;

namespace LNF_Civilians
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
        OpenFileDialog openFd;
        string imglocation = "";
        string name = "";
        string imgurl = "";
        string accessKey = "AKIAIQN25HEKFWO3U5AA";
        string secretKey = "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";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.APSouth1);

            String collectionId = "Faces";
            MessageBox.Show("Creating collection: " + collectionId);

            CreateCollectionRequest createCollectionRequest = new CreateCollectionRequest()
            {
                CollectionId = collectionId
            };

            CreateCollectionResponse createCollectionResponse = rekognitionClient.CreateCollection(createCollectionRequest);
            MessageBox.Show("CollectionArn : " + createCollectionResponse.CollectionArn);
            MessageBox.Show("Status code : " + createCollectionResponse.StatusCode);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.APSouth1);

            MessageBox.Show("Listing collections");
            int limit = 10;

            ListCollectionsResponse listCollectionsResponse = null;
            String paginationToken = null;
            do
            {
                if (listCollectionsResponse != null)
                    paginationToken = listCollectionsResponse.NextToken;

                ListCollectionsRequest listCollectionsRequest = new ListCollectionsRequest()
                {
                    MaxResults = limit,
                    NextToken = paginationToken
                };

                listCollectionsResponse = rekognitionClient.ListCollections(listCollectionsRequest);

                foreach (String resultId in listCollectionsResponse.CollectionIds)
                    MessageBox.Show(resultId);
            } while (listCollectionsResponse != null && listCollectionsResponse.NextToken != null);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FIR f = new FIR();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String collectionId = "Faces";
            AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.APSouth1);
            ListFacesResponse listFacesResponse = null;
            MessageBox.Show("Faces in collection " + collectionId);

            String paginationToken = null;
            do
            {
                if (listFacesResponse != null)
                    paginationToken = listFacesResponse.NextToken;

                ListFacesRequest listFacesRequest = new ListFacesRequest()
                {
                    CollectionId = collectionId,
                    MaxResults = 1,
                    NextToken = paginationToken
                };

                listFacesResponse = rekognitionClient.ListFaces(listFacesRequest);
                foreach (Face face in listFacesResponse.Faces)
                    MessageBox.Show(face.FaceId);
            } while (listFacesResponse != null && !String.IsNullOrEmpty(listFacesResponse.NextToken));

        }

        private void button5_Click(object sender, EventArgs e)
        {
            String collectionId = "Faces";
            AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.APSouth1);
            ListFacesResponse listFacesResponse = null;
            MessageBox.Show("Faces in collection " + collectionId);

            String paginationToken = null;
            do
            {
                if (listFacesResponse != null)
                    paginationToken = listFacesResponse.NextToken;

                ListFacesRequest listFacesRequest = new ListFacesRequest()
                {
                    CollectionId = collectionId,
                    MaxResults = 1,
                    NextToken = paginationToken
                };

                listFacesResponse = rekognitionClient.ListFaces(listFacesRequest);
                foreach (Face face in listFacesResponse.Faces)
                    MessageBox.Show(face.FaceId);
            } while (listFacesResponse != null && !String.IsNullOrEmpty(listFacesResponse.NextToken));


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 100;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            datagridrefresh();
            timer1.Interval = 10000;
            
        }
        public void datagridrefresh()
        {
            try
            {


                cn.Close();
                cn.Open();
                string query = "select * from LNFir";
                SqlDataAdapter sda = new SqlDataAdapter(query, cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();

            }
            catch (Exception e1)
            {

            }
            finally
            {
                cn.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MatchFace mf = new MatchFace();
            mf.Show();
        }
    }
}
