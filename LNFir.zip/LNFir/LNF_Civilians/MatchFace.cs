﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using System.Data.SqlClient;

namespace LNF_Civilians
{
    public partial class MatchFace : MetroFramework.Forms.MetroForm
    {
        SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
        OpenFileDialog openFd;
        string imglocation = "";
        string name = "";
        string imgurl = "";
        string accessKey = "AKIAIQN25HEKFWO3U5AA";
        string secretKey = "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";

        String collectionId = "Faces";
        String bucket = "lnf-data";
        String photo="";

        public MatchFace()
        {
            InitializeComponent();
        }

        private void MatchFace_Load(object sender, EventArgs e)
        {




        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                openFd = new OpenFileDialog();
                openFd.Filter = "Images only. |*.jpg;*.png;";
                if (openFd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = openFd.FileName;
                    imglocation = pictureBox1.ImageLocation.ToString();
                   
                    name = openFd.SafeFileName;
                    //MessageBox.Show(name);
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show("Please select a valid image.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string imageName = "";
                string endpoint = "http://s3.ap-south-1.amazonaws.com/lnf-data/";
                String collectionId = "Faces";
                String bucketName = "lnf-data";

                IAmazonS3 client = new AmazonS3Client(accessKey, secretKey, RegionEndpoint.APSouth1);
                TransferUtility utility = new TransferUtility(client);
                TransferUtilityUploadRequest request = new TransferUtilityUploadRequest();
                request.BucketName = bucketName;
                string keyname = "app-images/" + name;
                request.Key = keyname;
                //MessageBox.Show(keyname);
                //MessageBox.Show(imgLocation);
                request.FilePath = imglocation;
                utility.Upload(request);
                imgurl = endpoint + keyname;

                AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.APSouth1);

                // Get an image object from S3 bucket.
                Image image = new Image()
                {
                    S3Object = new S3Object()
                    {
                        Bucket = bucket,
                        Name = "app-images/" + name
                    }
                };

                SearchFacesByImageRequest searchFacesByImageRequest = new SearchFacesByImageRequest()
                {
                    CollectionId = collectionId,
                    Image = image,
                    FaceMatchThreshold = 70F,
                    MaxFaces = 2
                };

                SearchFacesByImageResponse searchFacesByImageResponse = rekognitionClient.SearchFacesByImage(searchFacesByImageRequest);

                MessageBox.Show("Faces matching largest face in image from " + photo);
                foreach (FaceMatch face in searchFacesByImageResponse.FaceMatches)
                {
                    MessageBox.Show("FaceId: " + face.Face.FaceId + " Image Name: " + face.Face.ExternalImageId + ", Similarity: " + face.Similarity);
                    imageName = face.Face.ExternalImageId;
                    break;
                }
                string faceDetailImageName = "http://s3.ap-south-1.amazonaws.com/lnf-data/fir-images/"+imageName;
                getdata(faceDetailImageName);

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
        }
        public void  getdata(string name)
        {
            try
            {


                cn.Close();
                cn.Open();
                string query = "select * from LNFir where photo='"+name+"'";
                SqlDataAdapter sda = new SqlDataAdapter(query, cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();

            }
            catch (Exception e1)
            {

            }
            finally
            {
                cn.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
