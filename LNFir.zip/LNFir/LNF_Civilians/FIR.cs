﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using System.Data.SqlClient;

namespace LNF_Civilians
{
    public partial class FIR : MetroFramework.Forms.MetroForm
    {
        OpenFileDialog openFd;
        string imglocation = "";
        string name = "";
        string imgurl = "";
        string accessKey = "AKIAIQN25HEKFWO3U5AA";
        string secretKey = "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";
        public FIR()
        {
            InitializeComponent();
        }

        private void FIR_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                openFd = new OpenFileDialog();
                openFd.Filter = "Images only. |*.jpg;*.png;";
                if (openFd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = openFd.FileName;
                    imglocation = pictureBox1.ImageLocation.ToString();
                    name = openFd.SafeFileName;
                    //MessageBox.Show(name);
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show("Please select a valid image.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                try
                {
                    string endpoint = "http://s3.ap-south-1.amazonaws.com/lnf-data/";
                    String collectionId = "Faces";
                    String bucketName = "lnf-data";

                    IAmazonS3 client = new AmazonS3Client(accessKey, secretKey, RegionEndpoint.APSouth1);
                    TransferUtility utility = new TransferUtility(client);
                    TransferUtilityUploadRequest request = new TransferUtilityUploadRequest();
                    request.BucketName = bucketName;
                    string keyname = "fir-images/" + name;
                    request.Key = keyname;
                    //MessageBox.Show(keyname);
                    //MessageBox.Show(imgLocation);
                    request.FilePath = imglocation;
                    utility.Upload(request);
                    imgurl = endpoint + keyname;
                    //MessageBox.Show(imgurl);
                    String bucket = "lnf-data";

                    AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.APSouth1);
                    Amazon.Rekognition.Model.Image image = new Amazon.Rekognition.Model.Image()
                    {
                        S3Object = new S3Object()
                        {
                            Bucket = bucket,
                            Name = "fir-images/" + name
                        }
                    };

                    IndexFacesRequest indexFacesRequest = new IndexFacesRequest()
                    {
                        Image = image,
                        CollectionId = collectionId,
                        ExternalImageId = name,
                        DetectionAttributes = new List<String>() { "ALL" }
                    };

                    IndexFacesResponse indexFacesResponse = rekognitionClient.IndexFaces(indexFacesRequest);

                    // MessageBox.Show(name + " added");
                    foreach (FaceRecord faceRecord in indexFacesResponse.FaceRecords)
                        MessageBox.Show("Face detected: Faceid is " +
                       faceRecord.Face.FaceId);
                    string query = string.Format("insert into LNFir(fullName, hisName, relation, fatherName, description, lostDate, address, lastPlace, mobileNumber, photo, matchStatus) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}',0)", textBox1.Text.Trim(), textBox2.Text.Trim(), textBox3.Text.Trim(), textBox6.Text.Trim(), textBox5.Text.Trim(), dateTimePicker1.Text.Trim(), textBox9.Text.Trim(), textBox8.Text.Trim(), textBox7.Text.Trim(), imgurl);
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record submitted.");
                    cn.Close();

                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    cn.Close();
                }
            }
            catch (Exception e1)
            {

            }

        }
    }
}
